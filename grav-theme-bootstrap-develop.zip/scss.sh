#!/bin/sh
scss --sourcemap --watch scss:css-compiled
